library(testthat)
library(grupa0Faza3)

test_check("grupa0Faza3")
