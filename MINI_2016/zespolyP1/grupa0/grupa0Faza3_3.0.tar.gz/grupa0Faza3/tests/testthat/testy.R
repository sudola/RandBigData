library(testthat)
library(grupa0Faza3)


test_that("wykres_czasow_typowej_sciezki",{
  expect_error(wykres_czasow_typowej_sciezki())
  
  expect_error(wykres_czasow_typowej_sciezki(podaj_rok = "2012"))
  
  expect_error(wykres_czasow_typowej_sciezki(podaj_rok = 2015,
                                             podaj_miesiac = 12))
  expect_error(wykres_czasow_typowej_sciezki(podaj_rok = 2010,
                                             podaj_miesiac = 12))
  })

  test_that("popularna",{
  expect_error(wykres_popularna(popularne_ciekawe))
  
  expect_error(tabela_popularna(popularne_ciekawe))
  
  expect_error(tabela_popularna(popularne_miesiace))
  
  expect_output(tabela_popularna(popularne_miesiac, 
                                 in_miesiac_rok="2012-02"), 
                                  "data frame")
  
  })
  
  test_that("dystrybuanta",{
  expect_error(dystrybuanta_sciezek(podaj.grupe="czesc_tyg", podaj.rok=NA, 
                                    podaj.czesc.tyg="sobota"))
  
  expect_error(dystrybuanta_sciezek(podaj.grupe="rok", podaj.rok=2010, 
                                    podaj.czesc.tyg=NA))
  
  expect_error(dystrybuanta_sciezek(podaj.grupe="rok", podaj.rok=2014, 
                                    podaj.czesc.tyg="sobota"))
  
  })
  
  test_that("histogram",{
  expect_error(hist_sciezek(podaj.grupe="czesc_tyg", podaj.rok=NA, 
                                    podaj.czesc.tyg="sobota"))
  
  expect_error(hist_sciezek(podaj.grupe="rok", podaj.rok=2010, 
                                    podaj.czesc.tyg=NA))
  
  expect_error(hist_sciezek(podaj.grupe="rok", podaj.rok=2014, 
                                    podaj.czesc.tyg="sobota"))
  
  })
  
  test_that("aktywnosc",{
  
  expect_error(tabela_aktywnosc(podaj.typ="najbardziej", 
                                 podaj.rok=2017, 
                                 podaj.miesiac=1, 
                                 podaj.czesc="cały tydzień"))
    
    expect_error(wykres_aktywnosc(podaj.typ="najmniej", 
                                podaj.rok=2017, 
                                podaj.miesiac=1, 
                                podaj.czesc="weekend"))
    
    expect_error(wykres_aktywnosc(podaj.typ="najbardziej", 
                                podaj.rok=2017, 
                                podaj.miesiac=12, 
                                podaj.czesc=c("weekend","cały tydzień","dni robocze")))
    
    
    expect_error(wykres_aktywnosc(podaj.typ="najmniej", 
                                podaj.rok=2013, 
                                podaj.miesiac=15, 
                                podaj.czesc="weekend"))
    
    })
  
  test_that("skrajne",{
  
  expect_error(tabela_skrajne(podaj.kolejnosc="najbardziej", 
                                podaj.rok=2017, 
                                podaj.miesiac=1, 
                                podaj.czesc="weekend"))
  
  expect_error(tabela_skrajne(podaj.kolejnosc="najbardziej", 
                                podaj.rok=2017, 
                                podaj.miesiac=1, 
                                podaj.czesc=c("weekend","cały tydzień","dni robocze")))
  
  
  expect_error(wykres_skrajne(podaj.kolejnosc="pierwszy", 
                              podaj.rok=2012, 
                              podaj.miesiac=20, 
                              podaj.czesc="weekend"))
  
  expect_error(wykres_skrajne(podaj.kolejnosc="ostatni", 
                              podaj.rok=1992, 
                              podaj.miesiac=12, 
                              podaj.czesc=c("weekend","cały tydzień","dni robocze")))
  

})