#' Opis danych liczebnosci_sc
#'
#' Dane zawierające najczęstsze liczebności każdej długości ścieżki (tj. liczby odwiedzonych eksponatów).
#' w podziale na  roku i część tygodnia (dni robocze oraz weekend) z lat 2012–2015. 
#' Nie uwzględniono logowań krótszych niż 5s oraz poniedziałków. 
#'
#' @docType data
#' @keywords datasets
#' @name liczebnosci_sc
#' @usage data(liczebnosci_sc)
#' 
NULL