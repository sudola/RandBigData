#' @title Histogram liczby długości ścieżek
#'
#' @description Histogram liczby długości ścieżek w zależności od (wybranego roku 
#' bądź części tygodnia) i liczebności/częstości. Musi być podany co najmniej jeden 
#' parametr (wtedy drugi). 
#' W przypadku niewybrania domyślnej wartości pierwszego. parametru, musi być podana
#' wartość trzeciego parametru. Parametr drugi i trzeci są komplementarne, wybór wartości jednego 
#' z nich innej niż domyślna wymusza domyślną wartość na drugim.
#' 
#' @usage hist_sciezek(podaj.grupe, podaj.rok, podaj.czesc.tyg, podaj.typ)
#' 
#' @param podaj.grupe oznacza wybór grupy, tzn. dane z roku ("rok"), 
#' czy z części tygodnia ("czesc_tyg"). Domyślnie "rok".
#' @param podaj.rok oznacza wybór roku (1 rok albo 2 lata) z lat 2012–2015, 
#' domyślnie lata NA.
#' @param podaj.czesc.tyg oznacza wybór części tygodnia ("dni_robocze" albo
#' "weekend"), domyślnie NA.
#' @param podaj.typ oznacza typ prezentacji wyników, tzn. zaznaczanie na osi
#' rzędnych liczebności ("liczebnosci", domyślnie) albo częstości ("czestosci").
#'
#' @return wykres
#'
#' @examples 
#' \dontrun{
#' hist_sciezek(,2012,)
#' hist_sciezek("czesc_tyg",,"weekend")
#' hist_sciezek(,2012:2013)
#' hist_sciezek("czesc_tyg",,c("dni_robocze", "weekend"))
#' }
#' 
#' @import dplyr
#' @import ggplot2
#' @export

hist_sciezek <- function(podaj.grupe="rok",
                         podaj.rok=NA,
                         podaj.czesc.tyg=NA,
                         podaj.typ="liczebnosci"){
  
  stopifnot(podaj.grupe %in% c("rok", "czesc_tyg"),
            podaj.rok %in% c(2012:2015, NA), 
            length(podaj.rok) <3,
            podaj.czesc.tyg %in% c("dni_robocze", "weekend", NA),
            podaj.typ %in% c("liczebnosci", "czestosci"))
  
  podaj.czesc.tyg <- factor(gsub("[[:punct:]]", " ", podaj.czesc.tyg))
  
  gr <- podaj.grupe
  if (podaj.grupe=="czesc_tyg"){
    podaj.grupe <- "część tygodnia"
  }
  
  if (podaj.grupe=="rok"){
    wartosci <- as.character(podaj.rok)
  }
  else{
    wartosci <- podaj.czesc.tyg
  }
  liczebnosci_sc <- liczebnosci_sc %>%
    mutate(rok=factor(rok))
  
  if (podaj.typ=="liczebnosci"){
    gg <- liczebnosci_sc %>% 
      select(dlug_sc, liczebnosci, grupa=contains(gr)) %>%
      filter(grupa %in% wartosci) %>%
      group_by(dlug_sc, grupa) %>%
      summarise(liczebnosci=sum(liczebnosci)) %>%
      ungroup() %>%
      mutate(liczebnosci=liczebnosci/1000)
  
    ggplot(gg, aes(x=dlug_sc, y=liczebnosci, group=grupa, fill=grupa)) +
    geom_bar(stat = "identity", alpha=.5,  position = "identity")+
    scale_fill_manual(values=c("blue", "orange"), 
                               name=podaj.grupe)+
    labs(x="Długość ścieżki", y="Liczebności [tys.]", 
        title="Liczba ścieżek danej długości") +
    theme(plot.title = element_text(size=20, face="bold", margin = margin(10, 10, 10, 10)),
          axis.title = element_text(face="bold",size=13)) +
    scale_x_continuous(breaks=seq(0,max(gg$dlug_sc),5))+
    scale_y_continuous(breaks=seq(0, plyr::round_any(max(gg$liczebnosci),20),length.out=5))
    }
    
    else {
      gg <- liczebnosci_sc %>% 
        select(dlug_sc, liczebnosci, grupa=contains(gr)) %>%
        filter(grupa %in% wartosci) %>%
        group_by(dlug_sc, grupa) %>%
        summarise(liczebnosci=sum(liczebnosci)) %>%
        group_by(grupa) %>%
        mutate(liczebnosci=liczebnosci*100/sum(liczebnosci))
      
      ggplot(gg, aes(x=dlug_sc, y=liczebnosci, group=grupa, fill=grupa)) +
      geom_bar(stat = "identity",  alpha=.5, position = "identity")+
      scale_fill_manual(values=c("blue", "orange"),
                                 name=podaj.grupe)+
      labs(x="Długość ścieżki", y="Częstości [%]", 
          title="Liczba ścieżek danej długości") +
      theme(plot.title = element_text(size=20, face="bold", margin = margin(10, 10, 10, 10)),
            axis.title = element_text(face="bold",size=13)) +
      scale_x_continuous(breaks=seq(0,max(gg$dlug_sc),5))+
      scale_y_continuous(breaks=seq(0,plyr::round_any(max(gg$liczebnosci),.5),by=.5))
    }
}