#' Opis danych sredniaRocznaT
#' 
#' Są to dane zawierające średnie czasów spędzonych przy kolejnych eksponatach
#' w dniach wtorek, środa, czwartek i piątek dla miesięcy w latach 2012-2015.
#' 
#' @docType data
#' @keywords datasets
#' @name sredniaRocznaT
#' @usage data(sredniaRocznaT)
#' 
NULL
