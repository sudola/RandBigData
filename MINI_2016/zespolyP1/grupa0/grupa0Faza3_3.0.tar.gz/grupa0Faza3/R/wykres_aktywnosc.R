#' @title Wykres najbardziej/najmniej aktywnych eksponatów
#'
#' @description Graficznie przedstawienie najbardziej/najmniej aktywnych eksponatów 
#' w zależności od długości ścieżki. Przez aktywność rozumiany jest sumaryczny czas,
#' kiedy urządzenie było aktywne, tzn. karta odwiedzającego była włożona.
#' Wśród opcji funkcji wybiera sie rodzaj ekstremum, część tygodnia, rok i miesiąc,
#' z których dane mają być prezentowane. Nie są prezentowane dane dla ścieżek dłuższych niż 
#' 40 eksponatów oraz jeśli tę samą wartość ekstremum ma więcej niż trzy eksponaty.
#'
#' @usage wykres_aktywnosc(podaj.typ, podaj.rok, podaj.miesiac)
#' 
#' @param podaj.typ oznacza wybór najbardziej ("najbardziej") bądź najmniej ("najmniej") 
#' aktywnych eksponatów, domyślnie "najbardziej".
#' @param podaj.rok oznacza wybór jednego roku, 2012—2015, domyślnie 2012.
#' @param podaj.miesiac oznacza wybór  jednego miesiąca, domyślnie 01 (=styczeń).
#' @param podaj.czesc oznacza wybór części tygodnia, domyślnie 
#' cały tydzień ("cały tydzień"). Ponadto do wyboru "dni robocze" i "weekend". 
#' Można wybrać 1,2,3 poziomy parametru.
#' 
#' @return Wykres
#' 
#' @examples 
#' \dontrun{
#' wykres_aktywnosc()
#' wykres_aktywnosc("najmniej")
#' wykres_aktywnosc("najmniej", , ,"weekend")
#' wykres_aktywnosc(, 2013, 02)
#' wykres_aktywnosc("najmniej", 2013)
#' wykres_aktywnosc( , ,02, "weekend")
#' wykres_aktywnosc("najmniej", 2013, 02, "weekend")
#' wykres_aktywnosc("najmniej", 2013, 02, c("dni robocze", "weekend"))
#' }
#' 
#' 
#' @import dplyr
#' @import ggplot2
#' @import stringi
#' @export

wykres_aktywnosc <- function(podaj.typ="najbardziej", 
                            podaj.rok=2012, 
                            podaj.miesiac=01, 
                            podaj.czesc="cały tydzień"){
  
  stopifnot(podaj.typ %in% c("najbardziej", "najmniej"), 
            podaj.rok %in% 2012:2015,
            podaj.miesiac %in% 1:12, 
            podaj.czesc %in% c("weekend", "dni robocze", "cały tydzień"))
  
    podaj.czesc <- sort(podaj.czesc, decreasing=TRUE)
    gg <- aktywnosci %>% 
    filter(typ==podaj.typ & 
             rok==podaj.rok & 
             miesiac==podaj.miesiac & 
             czesc_tyg %in% podaj.czesc &
             dlug_sc <41) %>% 
    group_by(dlug_sc, czesc_tyg) %>% 
    filter(n()<4) %>%
    arrange(dlug_sc)

    ggplot(gg, aes(dlug_sc, eksponat, group=czesc_tyg, colour=czesc_tyg, shape=czesc_tyg))+
    geom_point(size=3)+ 
    labs(x="Długość ścieżki", y="Nr eksponatu", 
      title=paste0(stri_trans_totitle(podaj.typ), " aktywny eksponat \ndla danej długości ścieżki")) +
    theme(plot.title = element_text(size=20, face="bold", margin = margin(10, 10, 10, 10)),
          axis.title = element_text(face="bold",size=13)) +
    scale_x_continuous(breaks=seq(1, max(aktywnosci$dlug_sc), by=2))+
    #scale_y_coninuous(breaks=nazwy)+
    scale_shape_manual(values=c(15, 18,4), name="część tygodnia")+
    scale_colour_manual(values=c("green", "red", "blue"), 
                        name="część tygodnia")
}