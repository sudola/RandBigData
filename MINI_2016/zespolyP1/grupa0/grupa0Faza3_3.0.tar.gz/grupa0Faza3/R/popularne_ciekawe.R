#' Opis danych popularne_ciekawe
#' 
#' Zbiór danych zawiera najciekawsze popularne ścieżki z CNK w latach 2012-2015.
#' 
#' @docType data
#' @keywords datasets
#' @name popularne_ciekawe
#' @usage data(popularne_ciekawe)
#' 
NULL