#' Tabela popularnej ścieżki
#'
#' Funkcja tabela_popularna() prezentuje podsumowanie dotyczące popularnej ścieżki, 
#' tzn. tabela zawiera informacje ile eksponatów było na danym miejscu ścieżki,
#' oraz podaje procentową liczbę odwiedzających te eksponaty.
#'
#' @param ramka Zbiór danych, z którego będą wybierane ścieżki.
#' @param in_miesiac_rok Miesiąc w danym roku, dla którego ma być pokazana ścieżka.
#' @param in_data Data, dla której ma być pokazana ścieżka.
#'
#' @examples \dontrun{
#' tabela_popularna(popularne_ciekawe, in_data="2012-01-14")
#' tabela_popularna(popularne_miesiac, in_miesiac_rok="2012-02")}
#'
#' @import dplyr
#' @import ggplot2
#' @import reshape2
#' @export

tabela_popularna<-function(ramka, in_data=NA, in_miesiac_rok=NA){
  
  ramka<-data.frame(ramka)
  
  if(!is.na(in_data)){
    #ramka danych popularne_ciekawe
    sciezka<- ramka %>% filter(data==in_data)
    
  }else{
    if (!is.na(in_miesiac_rok)) { 
      #ramka danych popularne_miesiac
      sciezka<- ramka %>% filter(miesiac_rok==in_miesiac_rok)
      
    }else{
      stop("Błędnie podane argumenty! in_data lub in_mieisac_rok musi być różne od NA!")
    }
  }
  
  ile_eks<- sciezka %>% group_by(ktory) %>% summarise(ile=n())
  proc_tmp<-sciezka[,c("ktory","procent")] %>% unique()
  df_tmp<-left_join(ile_eks,proc_tmp, by="ktory")
  names(df_tmp)<-c("nr","ile_eksponatów","procent")
  
  return(df_tmp)
  
}
