#' @title Wykres dystrybuanty długości ścieżek
#'
#' @description Wykres dystrybuanty długości ścieżek w zależności od wybranego roku 
#' bądź części tygodnia. Musi być podany co  najmniej jeden parametr (wtedy drugi). 
#' W przypadku niewybrania domyślnej wartości pierwszego parametru, musi być podana
#' wartość trzeciego parametru. Parametr drugi i trzeci są komplementarne, wybór wartości jednego 
#' z nich innej niż domyślna wymusza domyślną wartość na drugim.
#' 
#' @usage dystrybuanta_sciezek(podaj.grupe, podaj.rok, podaj.czesc.tyg)
#' 
#' @param podaj.grupe oznacz wybór grupy, tzn. dane z roku ("rok"), 
#' czy z części tygodnia ("czesc_tyg"). Domyślnie "rok".
#' @param podaj.rok oznacza wybór roku (1 rok albo 2 lata) z lat 2012–2015, 
#' domyślnie lata NA.
#' @param podaj.czesc.tyg oznacza wybór części tygodnia ("dni_robocze" albo
#' "weekend"), domyślnie NA.
#'
#' @return Wykres
#'
#' @examples 
#' \dontrun{
#' dystrybuanta_sciezek(,2012,)
#' dystrybuanta_sciezek("czesc_tyg",,"weekend")
#' dystrybuanta_sciezek(,2012:2013)
#' dystrybuanta_sciezek("czesc_tyg",,c("dni_robocze", "weekend"))
#' }
#' 
#' @import dplyr
#' @import ggplot2
#' @export

dystrybuanta_sciezek <- function(podaj.grupe="rok",
                                 podaj.rok=NA,
                                 podaj.czesc.tyg=NA){
  
  
  stopifnot(podaj.grupe %in% c("rok", "czesc_tyg"),
            podaj.rok %in% c(2012:2015, NA), 
            length(podaj.rok) < 3,
            podaj.czesc.tyg %in% c("dni_robocze", "weekend", NA))
  
  podaj.czesc.tyg <- factor(gsub("[[:punct:]]", " ", podaj.czesc.tyg))
  
  if (podaj.grupe=="czesc_tyg"){
    gr <- "część tygodnia"
  }
  else{
    gr <- "rok"
  }
  
  if (podaj.grupe=="rok"){
    wartosci <- as.character(podaj.rok)
  }
  else{
    wartosci <- podaj.czesc.tyg
  }
  
  gg <- liczebnosci_sc %>% 
    mutate(rok=factor(rok)) %>% 
    select(dlug_sc, liczebnosci, grupa=contains(podaj.grupe)) %>%
    filter(grupa %in% wartosci) 
  
  ggplot(gg, aes(x=dlug_sc, y=cumsum(liczebnosci)/sum(liczebnosci), 
         group=grupa, colour=grupa, linetype=grupa)) +
  geom_step(size=1)+
  labs(x="Długość ścieżki", y="Wartość dystrybuanty", 
        title="Dystrubuanta długości ścieżek") +
  theme(plot.title = element_text(size=20, face="bold", margin = margin(10, 10, 10, 10)),
        axis.title = element_text(face="bold",size=13)) +
  scale_x_continuous(breaks=seq(0,plyr::round_any(max(gg$dlug_sc),5),5))+
  scale_y_continuous(breaks=0:10/10)+
  scale_colour_manual(values=c("blue", "orange"), 
                      name=gr)+
  scale_linetype_manual(values=c("solid", "twodash"), 
                      name=gr)
}