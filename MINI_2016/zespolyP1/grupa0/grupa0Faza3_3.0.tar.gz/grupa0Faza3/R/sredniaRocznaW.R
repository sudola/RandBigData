#' Opis danych sredniaRocznaW
#' 
#' Są to dane zawierające średnie czasów spędzonych przy kolejnych eksponatach
#' w weekend dla miesięcy w latach 2012-2015.
#' 
#' @docType data
#' @keywords datasets
#' @name sredniaRocznaW
#' @usage data(sredniaRocznaW)
#' 
NULL
