#' Wykres popularnej ścieżki
#'
#' Funkcja wykres_popularna() rysuje wykres popularnej ścieżki, tzn. dla danego dnia bądź 
#' przedziału czasu, funkcja wyznacza jaki eksponat był odwiedzany najczęściej 
#' jako pierwszy, który jako drugi, tworząc w ten sposób, niekoniecznie jednoznaczny, ciąg
#' najczęściej odwiedzanych eksponatów.
#'
#' @param ramka Zbiór danych, z którego bądą wybierane ścieżki.
#' @param in_miesiac_rok Miesiąc w danym roku, dla którego ma być pokazana ścieżka.
#' @param in_data Data, dla której ma być pokazana ścieżka.
#'
#' @examples \dontrun{
#' wykres_popularna(popularne_ciekawe, in_data="2012-01-14")
#' wykres_popularna(popularne_miesiac, in_miesiac_rok="2012-02")}
#'
#' @import dplyr
#' @import ggplot2
#' @import reshape2
#' @export

wykres_popularna<-function(ramka, in_data=NA, in_miesiac_rok=NA){
   ramka<-data.frame(ramka)
   if(!is.na(in_data)){
      #ramka danych popularne_ciekawe
      sciezka<- ramka %>% filter(data==in_data)
  
   }else{
      if (!is.na(in_miesiac_rok)) { 
         #ramka danych popularne_miesiac
         sciezka<- ramka %>% filter(miesiac_rok==in_miesiac_rok)
         
      }else{
         stop("Błędnie podane argumenty! in_data lub in_mieisac_rok musi być różne od NA!")
      }
   }
   dl_sciezki<-nrow(sciezka)
   sciezka_melt<-melt(sciezka)
   
   kolej_dawa_lata<-c("cnk02a","cnk02b","cnk03","cnk04","cnk05","cnk06","cnk07","cnk09",
                      "cnk10","cnk11","cnk13","cnk15","cnk16","cnk17","cnk19a","cnk19b","cnk20",
                      "cnk21","cnk66","cnk67","cnk68","cnk100","cnk12","cnk32","cnk34","cnk39",
                      "cnk40","cnk41","cnk42a","cnk43","cnk44","cnk45","cnk49",
                      "cnk54","cnk55","cnk56","cnk57","cnk58a","cnk58b","cnk59","cnk60","cnk61","cnk62",
                      "cnk69","cnk71","cnk72","cnk73","cnk79","cnk30","cnk37","cnk38","cnk46a","cnk46b",
                      "cnk47","cnk48a","cnk48b","cnk48c","cnk48d","cnk48e","cnk52","cnk53","cnk65",
                      "cnk70a","cnk70b","cnk70c","cnk74a","cnk75","cnk76","cnk18","cnk22",
                      "cnk23","cnk24","cnk25","cnk26","cnk27","cnk28","cnk29a","cnk31a","cnk31b",
                      "cnk31c","cnk31d","cnk78a","cnk78b","cnk36","cnk42b","cnk63a")
   
   sciezka_melt$eksponat<-ordered(sciezka_melt$eksponat,levels=kolej_dawa_lata)
   
   ggplot(sciezka_melt,aes(x=eksponat,y=value))+geom_point()+
      theme(axis.text.x=element_text(angle=45, size=10, vjust=0.5))+
      labs(x="Eksponat", y="Numer eksponatu w ścieżce", title='Wykres popularnej ścieżki')+
      scale_y_continuous(breaks = seq(0,dl_sciezki,2))
}
