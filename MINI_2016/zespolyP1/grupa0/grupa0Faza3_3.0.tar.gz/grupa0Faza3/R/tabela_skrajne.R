#' @title Najczęstsze skrajne eksponaty
#'
#' @description Tabelaryczne przedstawienie zawierające najczęstsze skrajne 
#' (=pierwsze/ostatnie) eksponaty dla danej długości ścieżki.
#' Paremetry funkcji służą określaniu, czy mają być rysowane pierwsze/ostatnie najczęstsze 
#' eksponaty, wybraniu podziału  tygodnia na dni robocze, weekend i cały tydzień, a także
#' roku i miesiąca, z których zbiór danych ma być prezentowany.
#'
#' @usage tabela_aktywnosc(podaj.typ, podaj.rok, podaj.miesiac)
#' 
#' @param podaj.kolejnosc oznaczy wybór pierwszych ("pierwszy", domyślnie) bądź
#' ostatnich ("ostatni") eksponatów.
#' @param podaj.rok oznacza wybór jednego roku 2012—2015, domyślnie 2012. 
#' @param podaj.miesiac oznacza wybór jednego miesiąca, domyślnie 01 (=styczeń).
#' @param podaj.czesc.tyg oznacza wybór części tygodnia, domyślnie 
#' cały tydzień ("cały tydzień"). Ponadto do wyboru "dni robocze" 
#' i "weekend". Można wybrać 1,2,3 poziomy parametru.
#' 
#' @return tabela
#' 
#' @examples 
#' \dontrun{
#' tabela_skrajne()
#' tabela_skrajne("ostatni")
#' tabela_skrajne("ostatni", , ,"weekend")
#' tabela_skrajne(, 2013, 02)
#' tabela_skrajne("ostatni", 2013)
#' tabela_skrajne( , ,02, "weekend")
#' tabela_skrajne("ostatni", 2013, 02, "weekend")
#' tabela_skrajne("ostatni", 2013, 02, c("dni robocze", "weekend"))
#' }
#' 
#' @import dplyr
#' @export


tabela_skrajne<- function(podaj.kolejnosc="pierwszy", 
                          podaj.rok=2012, 
                          podaj.miesiac=01, 
                          podaj.czesc.tyg="cały tydzień"){
  
  stopifnot(podaj.kolejnosc %in% c("pierwszy", "ostatni"), 
            podaj.rok %in% 2012:2015,
            podaj.miesiac %in% 1:12, 
            podaj.czesc.tyg %in% c("weekend", "dni robocze", "cały tydzień"))
  
  
  tab <- skrajne %>% 
    filter(kolejnosc==podaj.kolejnosc & 
             rok==podaj.rok & 
             miesiac==podaj.miesiac & 
             czesc_tyg %in% podaj.czesc.tyg) %>%
    mutate(procent=round(procent, digits=2)) %>%
    select(dlug_sc, liczba_eks, eksponat, suma_eks, procent, czesc_tyg) %>%
    arrange(czesc_tyg) %>%
    rename(`długość ścieżki`= dlug_sc, `liczba odwiedzających` =suma_eks, 
           `liczba eksponatów`=liczba_eks, `część tygodnia`=czesc_tyg)
  
  if (length(podaj.czesc.tyg)==1){
    tab <- select(tab, -`część tygodnia`)
  }
  
  return(tab)
} 