#' Opis danych medianaRocznaW
#' 
#' Są to dane zawierające mediany czasów spędzonych przy kolejnych eksponatach
#' w weekend dla miesięcy w latach 2012-2015.
#' 
#' @docType data
#' @keywords datasets
#' @name medianaRocznaW
#' @usage data(medianaRocznaW)
#' 
NULL
