#' Opis danych aktywnosci
#'
#' Dane zawierające najaktywniejsze i najmniej aktywne eksponaty (jeśli chodzi o sumaryczny 
#' czas pracy) w podziale na długość ścieżki (tj. liczby odwiedzonych eksponatów), 
#' część tygodnia, miesiąc oraz rok. Dane obejmują okres od  stycznia 2012 r. 
#' do listopada 2015 r. Część tygodnia to dane z weekendu, dni roboczych bądź 
#' całego tygodnia.
#' Nie uwzględniono logowań krótszych niż 5s ani poniedziałków, natomiast w przypadku najmniej 
#' aktywnych eksponatów czas pracy musiał być dłuższy niż 0s (taka sytuacja mogła sie 
#' zdarzyć pomimo filtracji, ponieważ eksponat mógł być nie używany np. podczas weekendu).
#' 
#' @docType data
#' @keywords datasets
#' @name aktywnosci
#' @usage data(aktywnosci)
#' 
NULL