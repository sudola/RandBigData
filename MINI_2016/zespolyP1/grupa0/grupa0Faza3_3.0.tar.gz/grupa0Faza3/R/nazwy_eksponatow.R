#' Opis danych nazwy_eksponatow
#'
#' Dane zawierają numery eksponatów oraz ich pełne nazwy. Niektórych eksponatów
#' nie było na otrzymanej liście dlatego zostały im nadane sztuczne numery 
#' tj. cnk153, cnk178, cnk179 i cnk237.
#' 
#' @docType data
#' @keywords datasets
#' @name nazwy_eksponatow
#' @usage data(nazwy_eksponatow)
#' 
NULL