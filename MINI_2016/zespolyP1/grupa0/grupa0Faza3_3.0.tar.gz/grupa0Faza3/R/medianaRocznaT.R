#' Opis danych medianaRocznaT
#' 
#' Są to dane zawierające mediany czasów spędzonych przy kolejnych eksponatach 
#' w dniach wtorek, środa, czwartek i piątek dla miesięcy w latach 2012-2015.
#' 
#' @docType data
#' @keywords datasets
#' @name medianaRocznaT
#' @usage data(medianaRocznaT)
#' 
NULL
