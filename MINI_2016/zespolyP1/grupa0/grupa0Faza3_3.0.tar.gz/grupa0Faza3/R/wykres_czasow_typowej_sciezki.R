#' Wykres czasów typowej ścieżki
#'
#' Funkcja wykres_czasow_typowej_sciezki rysuje wykres mediany lub średniej czasów, 
#' który spędzili wszyscy odwiedzający mający ścieżkę długości co najmniej 20 eksponatów
#' w wybranym przedziale czasu przy kolejnym eksponacie występującym w ścieżce. 
#' Uwzględniony został podział na weekend i dni robocze. Za dni robocze uznawane są
#' "wtorek", "środa", "czwartek" oraz "piątek". Na osi odciętych znajdują się numery 
#' kolejnych eksponatów, natomiast na osi rzędnych czas w sekundach. 
#'
#' @usage wykres_czasow_typowej_sciezki(podaj_rok, podaj_miesiac, rodzaj_miary)
#'
#' @param podaj_rok Rok, dla którego robimy wykres, podajemy jako cyfrę.
#' @param podaj_miesiac Miesiąc, dla którego robimy wykres, podajemy jako cyfrę.
#' @param rodzaj_miary Miara czasu, do wyboru "srednia" oraz "mediana".
#'
#' @return Wykres liniowy.
#' 
#' @examples 
#' \dontrun{
#' wykres_czasow_typowej_sciezki(podaj_rok=2012, podaj_miesiac= 12, rodzaj_miary = "mediana")
#' wykres_czasow_typowej_sciezki(podaj_rok=2012, podaj_miesiac= 12, rodzaj_miary = "srednia")
#' wykres_czasow_typowej_sciezki(podaj_rok=2015, podaj_miesiac= 3, rodzaj_miary = "mediana")
#'}
#'
#' @import dplyr
#' @import ggplot2
#'
#' @export


wykres_czasow_typowej_sciezki<-function(podaj_rok,podaj_miesiac,rodzaj_miary){
  
  stopifnot(length(podaj_miesiac)==1, length(podaj_rok)==1, length(rodzaj_miary)==1,
            podaj_rok %in% c(2012,2013,2014,2015), podaj_miesiac %in% 1:12, 
            rodzaj_miary %in% c("srednia", "mediana"))
  
  if(podaj_rok %in% c(2014,2015)  & podaj_miesiac==12){
    return("Brak danych dla wybranego przedziału czasu, podaj inną datę.")
  } 
  
  if(podaj_rok==2015  & podaj_miesiac==11 ){
    return("Brak danych dla wybranego przedziału czasu, podaj inną datę.")
  } 
  
  if(rodzaj_miary=="srednia"){
    sredniaRocznaT<-data.frame(sredniaRocznaT)
    A<-sredniaRocznaT %>%
      filter(rok==podaj_rok)
    x1<-A[podaj_miesiac,2:31]
    
    sredniaRocznaW<-data.frame(sredniaRocznaW)
    B<-sredniaRocznaW %>%
      filter(rok==podaj_rok)
    x2<-B[podaj_miesiac,2:31]
    
  }else{
    medianaRocznaW<-data.frame(medianaRocznaW)
  
    B<-medianaRocznaW %>%
      filter(rok==podaj_rok)
    x2<-B[podaj_miesiac,2:31]
    
    medianaRocznaT<-data.frame(medianaRocznaT)
    A<-medianaRocznaT %>%
      filter(rok==podaj_rok)
    x1<-A[podaj_miesiac,2:31]
  }
  
  if(rodzaj_miary=="srednia"){rodzaj_miary="średniej"
  }else{rodzaj_miary="mediany"}
  
  y=c(1:30,1:30)
  
  Legenda=c(rep("dni robocze",30),rep("weekend",30))
  x<-as.character(c(x1,x2))
  ramka<-data.frame(x=as.numeric(x), y=y, Legenda=Legenda)
  
  miesiace<-c("styczeń","luty","marzec","kwiecień","maj","czerwiec","lipiec",
              "sierpień","wrzesień","październik","listopad","grudzień")
  
  ggplot(data=ramka, aes(y,x,fill=Legenda))+
    geom_point(size=2,aes(color=Legenda)) +
    geom_line(aes(color=Legenda))+
    labs(x="Nr odwiedzanego eksponatu", y="Czas [s]",title=paste0("Wykres ",rodzaj_miary," czasów w miesiącu ",miesiace[podaj_miesiac]))+
    theme(plot.title = element_text(size=25, face="bold"),axis.title = element_text(face="bold", size=15)) 
  
}
