#' Opis danych skrajne
#'
#' Dane zawierające najczęstsze skrajne (=pierwsze i ostatnie) eksponaty w podziale na
#' długość ścieżki, część tygodnia, rok i miesiąc. Dane obejmują
#' okres od stycznia 2012 r. do listopada 2015 r. Części tygodnia to dane z weekendu,
#' dni roboczych bądź całego tygodnia.
#' Nie uwzględniono logowań krótszych niż 5s ani poniedziałków.
#'
#' @docType data
#' @keywords datasets
#' @name skrajne
#' @usage data(skrajne)
#' 
NULL