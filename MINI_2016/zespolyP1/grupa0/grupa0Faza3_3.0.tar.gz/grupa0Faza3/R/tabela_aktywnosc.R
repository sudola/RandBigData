#' @title Najbardziej/najmniej aktywne eksponaty
#'
#' @description Tabelaryczne przedstawienie najbardziej/najmniej aktywnych eksponatów 
#' w zależności od długości ścieżki. Przez aktywność rozumiany jest sumaryczny czas,
#' kiedy urządzenie było aktywne, tzn. karta odwiedzającego była włożona.
#' Wśród opcji funkcji wybiera się rodzaj ekstremum, część tygodnia, rok i miesiąc
#' z których dane mają być prezentowane. Nie są prezentowane dane dla ścieżek dłuższych niż 
#' 40 eksponatów oraz jeśli tę samą wartość ekstremum ma więcej niż 3 eksponaty.
#'
#' @usage tabela_aktywnosc(podaj.typ, podaj.rok, podaj.miesiac)
#' 
#' @param podaj.typ oznacza wybór najbardziej ("najbardziej") bądź najmniej ("najmniej") 
#' aktywnych eksponatów, domyślnie "najbardziej".
#' @param podaj.rok oznacza wybór jednego roku, 2012—2015, domyślnie 2012.
#' @param podaj.miesiac oznacza wybór jednego miesiąca, domyślnie 01 (=styczeń).
#' @param podaj.czesc oznacza wybór części tygodnia, domyślnie cały tydzień ("cały tydzień").
#' Ponadto do wyboru "dni robocze" i "weekend". Można wybrać 1,2,3 poziomy parametru.
#' 
#' @return Tabela
#' 
#' @examples 
#' \dontrun{
#' tabela_aktywnosc()
#' tabela_aktywnosc("najmniej")
#' tabela_aktywnosc("najmniej", , ,"weekend")
#' tabela_aktywnosc(, 2013, 02)
#' tabela_aktywnosc("najmniej", 2013)
#' tabela_aktywnosc( , ,02, "weekend")
#' tabela_aktywnosc("najmniej", 2013, 02, "weekend")
#' tabela_aktywnosc("najmniej", 2013, 02, c("dni robocze", "weekend"))
#' }
#' 
#' @import dplyr
#' @export


tabela_aktywnosc <- function(podaj.typ="najbardziej", 
                             podaj.rok=2012, 
                             podaj.miesiac=01, 
                             podaj.czesc="cały tydzień"){
  
  stopifnot(podaj.typ %in% c("najbardziej", "najmniej"), 
            podaj.rok %in% 2012:2015,
            podaj.miesiac %in% 1:12, 
            podaj.czesc %in% c("weekend", "dni robocze", "cały tydzień"))
  
  
  tab <- aktywnosci %>% 
    filter(typ==podaj.typ & 
             rok==podaj.rok & 
             miesiac==podaj.miesiac & 
             czesc_tyg %in% podaj.czesc) %>%
    mutate(sum_czas=round(sum_czas/60, digits=2), procent=round(procent, digits=2)) %>%
    select(dlug_sc, liczba_eks, eksponat:sum_czas, procent, czesc_tyg) %>%
    arrange(czesc_tyg) %>%
    rename(`długość ścieżki`= dlug_sc, `suma czasów [min]`=sum_czas, 
           `liczba eksponatów`=liczba_eks, `część tygodnia`=czesc_tyg)
  
  if (length(podaj.czesc)==1){
    tab <- select(tab, -`część tygodnia`)
  }
  
  return(tab)
}  