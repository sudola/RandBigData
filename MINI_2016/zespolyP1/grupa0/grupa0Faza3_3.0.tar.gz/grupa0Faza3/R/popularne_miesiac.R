#' Opis danych popularne_miesiac
#' 
#' Zbiór danych zawiera popularne ścieżki z CNK dla każdego miesiąca z lat 2012-2015.
#' 
#' @docType data
#' @keywords datasets
#' @name popularne_miesiac
#' @usage data(popularne_miesiac)
#' 
NULL