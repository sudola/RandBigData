#' @title Wykres najczęstszych pierwszych/ostatnich eksponatów
#'
#' @description Graficznie przedstawienie najczęstszych pierwszych/ostatnich
#' eksponatów dla danej długości ścieżki.
#' Paremetry funkcji służa określania, czy mają być rysowane pierwsze/ostatnie najczęstsze 
#' eksponaty, wybrania podziału  tygodnia na dni robocze, weekend i cały tydzień, a także
#' roku i miesiąca, z których zbiór danych ma być prezentowany . 
#' Pokazywane są tylko ścieżki nie dłuższe niż 40-elementowe oraz nie mające więcej 
#' niż 3 eksponaty o tej samej liczbie odwiedzających.
#'
#' @usage wykres_skrajne(podaj.kolejnosc, podaj.rok, podaj.miesiac, podaj.czesc.tyg)
#' 
#' @param podaj.kolejnosc oznaczy wybór pierwszych ("pierwszy", domyślnie) bądź
#' ostatnich ("ostatni") eksponatów.
#' @param podaj.rok oznacza wybór jednego roku z lat 2012—2015, domyślnie 2012.
#' @param podaj.miesiac oznacza wybór jednego miesiąca, domyślnie 01 (=styczeń).
#' @param podaj.czesc.tyg oznacza wybór części tygodnia, domyślnie 
#' cały tydzień ("cały tydzień").
#' 
#' @return wykres
#' 
#' @examples 
#' \dontrun{
#' wykres_skrajne()
#' wykres_skrajne("ostatni")
#' wykres_skrajne("ostatni", "weekend")
#' wykres_skrajne(, 2013, 02)
#' wykres_skrajne("ostatni", 2013)
#' wykres_skrajne( , ,02, "weekend")
#' wykres_skrajne("ostatni", 2013, 02, "weekend")
#' wykres_skrajne("ostatni", 2013, 02, c("dni robocze", "weekend"))
#' }
#' 
#' @import dplyr
#' @import ggplot2
#' @export

wykres_skrajne <- function(podaj.kolejnosc="pierwszy", 
                           podaj.rok=2012, 
                           podaj.miesiac=01, 
                           podaj.czesc.tyg="cały tydzień"){
  
  stopifnot(podaj.kolejnosc %in% c("pierwszy", "ostatni"), 
            podaj.rok %in% 2012:2015,
            podaj.miesiac %in% 1:12, 
            podaj.czesc.tyg %in% c("weekend", "dni robocze", "cały tydzień"))
  
  
  gg <- skrajne %>% 
    filter(kolejnosc==podaj.kolejnosc & 
             rok==podaj.rok & 
             miesiac==podaj.miesiac & 
             czesc_tyg %in% podaj.czesc.tyg &
             dlug_sc <41) %>% 
    group_by(dlug_sc, czesc_tyg) %>% 
    filter(n()<4) %>%
    arrange(dlug_sc)
  
  ggplot(gg, aes(dlug_sc, eksponat, group=czesc_tyg, shape=czesc_tyg, 
                 colour=czesc_tyg))+
    geom_point(size=3)+
    labs(x="Długość ścieżki", y="Nr eksponatu", 
         title=paste0("Najczęstszy ", podaj.kolejnosc, 
                      " eksponat \ndla danej długości ścieżki")) +
    theme(plot.title = element_text(size=20, face="bold", margin = margin(10, 10, 10, 10)),
          axis.title = element_text(face="bold",size=13)) +
    #scale_x_continuous(breaks=seq(1, unique(max(krance$dlug_sc)), by=2))+
    scale_shape_manual(values=c(15, 18,4), name="część tygodnia")+
    scale_colour_manual(values=c("green", "red", "blue"), 
                        name="część tygodnia")
}