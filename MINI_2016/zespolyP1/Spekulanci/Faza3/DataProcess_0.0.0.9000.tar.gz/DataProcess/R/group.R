#' Opis danych
#'
#' Dane zawierają kolejne grupy obiektów odwiedzone 14-05-2013 dla stanowisk cnk06, cnk07 i cnk11
#' Opis kolumn:
#' \itemize{
#'    \item year. Rok
#'    \item month. Miesiac
#'    \item day. Dzień
#'    \item user. Numer karty użytkownika
#'    \item m_time. Średni czas użytkowania jednego stanowiska
#'    \item pozostałe. 0 - stanowisko nie zostało odwiedzone, 1 - stanowisko zostało odwiedzone
#' }
#'
#' @docType data
#' @keywords datasets
#' @name group
#' @usage data(group)
#'
NULL
