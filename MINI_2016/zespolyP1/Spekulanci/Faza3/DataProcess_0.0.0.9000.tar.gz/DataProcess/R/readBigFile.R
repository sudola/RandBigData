##' Funkja wewnętrzna
##'
##' Funkcja wczytuje duże pliki
##'
##' @param path - Ścieżka do pliku
##'


readBigFiles<-function(path){
   lines<- character()
   con <- file(description=path, open="r")
   repeat{
      nlines <- readLines(con, n =  1e+6)
      if (length(nlines)==0) break
      nlines <- grep(" WATCHDOG/WD ", nlines,  fixed = TRUE, value = TRUE, invert = TRUE)
      nlines <- grep(" WATCHDOG/STDERR ", nlines,  fixed = TRUE, value = TRUE, invert = TRUE)
      nlines <- grep(" WARN: ", nlines,  fixed = TRUE, value = TRUE, invert = TRUE)
      if(length(nlines)>0)
         linie=c(linie, nlines)
   }
   close(con)
   linie
}
