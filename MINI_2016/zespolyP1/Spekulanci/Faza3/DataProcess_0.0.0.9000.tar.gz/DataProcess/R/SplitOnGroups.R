##'
##' Funckaja tworzy ramkę danych z grupami odwiedzonych eksponatów
##'
##' Funkcja z danych tworzy ramkę danych zawieracjącą grupy odwiedzonych urządzeń przez jednego użytkownika
##'
##' @param data - dane wekstraktowane z logów
##'
##' @export
##' @import dplyr


splitOnGroups <- function(data){
   require(dplyr)

   code=t(data%>%select(hostname)%>%distinct())
   kod=paste("data%>%select(year,month,day,user,hostname,duration)%>%group_by(year,month,day,user)%>%summarise(stanowiska=toString(hostname), m_time=mean(duration))%>%mutate(",
             code[1],'=ifelse(stri_detect_regex(stanowiska, "',code[1],'($|,)"),1,0)', sep="")
   for(i in 2:length(code)){
      kod=paste(kod,", ",code[i],'=ifelse(stri_detect_regex(stanowiska, "',code[i],'($|,)"),1,0)', sep="")
   }
   kod=paste(kod, ")", sep = "")
   eval(parse(text = kod))
}
