#' Funkcja wewnętrzna
#'
#' Funckja tworzy listę podzbiorów dwuelementowych z liczb od 1 do n
#'
#' @param n - zakres liczb w pozdbiorach
#'

lista<-function(n){
   l<-vector(mode = "list", length = n*(n-1)/2)
   nn=1
   for(i in 1:(n-1)){
      for(j in (i+1):n){
         l[[nn]]=c(i,j)
         nn=nn+1
      }
   }
   l
}
