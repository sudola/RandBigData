#' Opis danych
#'
#' Ramka danych zawiera macierz przejścia w jednym kroku
#' Opis kolumn:
#' \itemize{
#'    \item start. stanowisko z którego zaczynamy
#'    \item pozostałe. Prawdopodobieństwo przejścia w jednym kroku do stanowiska o nazwie zmiennej
#' }
#'
#' @docType data
#' @keywords datasets
#' @name macierz_przejscia
#' @usage data(macierz_przejscia)
#'
NULL
