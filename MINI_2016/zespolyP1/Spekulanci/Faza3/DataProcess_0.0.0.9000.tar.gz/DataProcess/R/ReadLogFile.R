##' Funkcja wewnętrzna
##'
##' Funkcja wczytuje logi użytkowników
##'
##' @param path - Ścieżka do pliku
##' @param p - sciezka do pliku
##' @param h - hostname
##'



ReadLogFile<-function(path, p, h){
   rok <- strsplit(p, "/")[[1]][1]
   mies <- strsplit(p, "/")[[1]][2]

   if(file.info(file.path(path, p))$size<1024^3)
      lines <- readLines(file.path(path, p))
   else
      lines <- readBigFiles(file.path(path, p))

   lines <- grep(" WATCHDOG/STDERR ", lines,  fixed = TRUE, value = TRUE, invert = TRUE)
   lines <- grep(" WATCHDOG/WD ", lines,  fixed = TRUE, value = TRUE, invert = TRUE)
   lines <- grep(" WARN: ", lines,  fixed = TRUE, value = TRUE, invert = TRUE)
   MakeDataFrame(lines, rok, mies, h)
}
