##' Funkcja wczytująca dane
##'
##' Fuunkcja wczytuje dane z plików o rozszerzeniu .log i umiescza je w tabeli w bazie danych
##'
##' @param path - ścieżka do foldera w którym rozpakowane są foldery z danymi z wybranych lat o odpowiednim formacie
##' @param file - ścieżka do foldera w którym funkcja będzie zapisywała częsciowe wyniki w plikach .txt
##' @param pathdb - ścieżka do folderu zawierjącego bazę danych o nazwie filedb
##' @param filedb - nazwa pliku bazodanowego
##' @param tbname - nazwa pod jaką ma być zapisana ramka danych w bazodanowym pliku
##'
##' @export
##' @import RSQLite
##' @import stringi
##'


readLogs<- function(path, file, pathdb, filedb, tbname){
   require(RSQLite)
   require(stringi)
   stopifnot(file.exists(path), file.exists(file), file.exists(pathdb), is.character(filedb), is.character(tbname))

   pliki <- list.files(path = path, recursive = TRUE)
   pliki <- grep(".+\\.log", pliki, value = TRUE)
   pliki <- grep("cnk", pliki, value = TRUE)
   hostnames <- character()
   for (p in pliki){
      hostnames <- c(hostnames, basename(p))
   }
   hostnames <- unique(hostnames)
   hostnames <- unlist(lapply(strsplit(hostnames,"\\."), function(x){x[1]}))
   for(h in hostnames){

      pliki1 <- grep(paste(h,".",sep=""), pliki,  fixed = TRUE, value = TRUE)
      data <- data.frame(year=numeric(), month=numeric(), day=numeric(), time=character(),
                         duration=numeric(), user=character(), hostname=character())
      for (p in pliki1) {
         data <- rbind(ReadLogFile(path, p, h), data)
      }
      if (nrow(data)>0)
      {
         write.table(data, file.path(file,paste(h,".txt",sep = "")), row.names = T)
      }
   }
   sterownik <- dbDriver("SQLite")
   nowpath<-getwd()
   setwd(pathdb)
   polaczenie <- dbConnect(sterownik, paste(filedb, ".db", sep = ""))

   data=data.frame(year=numeric(), month=numeric(), day=numeric(), time=character(), duration=numeric(), user=numeric(), hostname=character())
   pliki <- list.files(path = file, recursive = TRUE)
   for (p in pliki){

      data1 <- read.table(file.path(file, p), skip = 1)
      data <- rbind(data, data1[,c(2:8)])

   }
   names(data) <- c("year", "month", "day", "time", "duration", "user", "hostname")
   dbWriteTable(polaczenie, tbname, data)
   setwd(nowpath)
}
