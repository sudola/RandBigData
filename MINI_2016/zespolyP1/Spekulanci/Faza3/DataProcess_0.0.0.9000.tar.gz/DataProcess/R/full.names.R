#' Opis danych
#'
#' Dane zawierają przypisanie pełnych nazw numerom cnk stanowisk.
#' Opis kolumn:
#' \itemize{
#'    \item code. Hostname stanowiska
#'    \item name. Pełna nazwa stanowiska
#' }
#'
#' @docType data
#' @keywords datasets
#' @name full.names
#' @usage data(full.names)
#'
NULL
