##'
##' Funckja zwracająca liczności wszystkich czwórek
##'
##' Funkcja zwraca czwórki eksponatów, które pojawiają się w ścieżkach
##'
##' @param grupy - Ramka danych z pogrupowanymi wystąpieniami eksponatów w ścieżkach. Składa się z samych zmiennych numeryccznych przyjmujących wartości 0 i 1.
##' @param corNumber - liczba rdzeni do zrównoleglenia operacji
##'
##' @export
##' @import parallel



four<-function(grupy, corNumber){
   require(parallel)
   stopifnot(all(sapply(grupy, unique) %in% c(0,1)), length(corNumber)==1, is.numeric(corNumber), 
             corNumber>1, nrow(grupy)>3)

   n=ncol(grupy)
   code=colnames(grupy)
   l=lista(n-2)

   if(corNumber>1){
      klaster=makeCluster(corNumber)

      czworki=parLapply(klaster, l, function(i, grupy){
         st3=st4=ile=numeric((n-1-i[2])*(n-i[2])/2)
         st1=rep(code[i[1]], (n-1-i[2])*(n-i[2])/2)
         st2=rep(code[i[2]], (n-1-i[2])*(n-i[2])/2)
         nn=1
         for(k in ((i[2]+1):(n-1))){
            for(l in ((k+1):n)){
               st3[nn]=code[k]
               st4[nn]=code[l]
               ile[nn]=sum(grupy[,i[1]]*grupy[,i[2]]*grupy[,k]*grupy[,l])
               nn=nn+1
            }
         }
         data.frame(st1,st2,st3,st4,ile)
      }, grupy=grupy)

      stopCluster(klaster)
   } else {
      czworki=lapply(l, function(i, grupy){
         st3=st4=ile=numeric((n-1-i[2])*(n-i[2])/2)
         st1=rep(code[i[1]], (n-1-i[2])*(n-i[2])/2)
         st2=rep(code[i[2]], (n-1-i[2])*(n-i[2])/2)
         nn=1
         for(k in ((i[2]+1):(n-1))){
            for(l in ((k+1):n)){
               st3[nn]=code[k]
               st4[nn]=code[l]
               ile[nn]=sum(grupy[,i[1]]*grupy[,i[2]]*grupy[,k]*grupy[,l])
               nn=nn+1
            }
         }
         data.frame(st1,st2,st3,st4,ile)
      }, grupy=grupy)

   }

   do.call("rbind", czworki)
}
