##'
##' Funckja zwracająca liczności wszystkich trójek
##'
##' Funkcja zwraca trójki eksponatów, które pojawiają się w ścieżkach
##'
##' @param - grupy Ramka danych z pogrupowanymi wystąpieniami eksponatów w ścieżkach. Składa się z samych zmiennych numeryccznych przyjmujących wartości 0 i 1.
##' @param - corNumber liczba rdzeni do zrównoleglenia operacji
##'
##' @export
##' @import parallel
##'

three<-function(grupy, corNumber){
   require(parallel)
   stopifnot(all(sapply(grupy, unique) %in% c(0,1)), length(corNumber)==1, is.numeric(corNumber), 
             corNumber>0, ncol(grupy)>2)

   n=ncol(grupy)
   code=colnames(grupy)
   l=lista(n-1)

   if(corNumber>1){
      klaster=makeCluster(corNumber)

      trojki=parLapply(klaster, l, function(i, grupy){
         st3=ile=numeric(n-i[2])
         st1=rep(code[i[1]], n-i[2])
         st2=rep(code[i[2]], n-i[2])
         nn=1
         for(k in (i[2]+1):n){
            st3[nn]=code[k]
            ile[nn]=sum(grupy[,i[1]]*grupy[,i[2]]*grupy[,k])
            nn=nn+1
         }
         data.frame(st1,st2,st3,ile)
      }, grupy=grupy)

      stopCluster(klaster)
   } else {
      trojki=lapply(l, function(i, grupy){
         st3=ile=numeric(n-i[2])
         st1=rep(code[i[1]], n-i[2])
         st2=rep(code[i[2]], n-i[2])
         nn=1
         for(k in (i[2]+1):n){
            st3[nn]=code[k]
            ile[nn]=sum(grupy[,i[1]]*grupy[,i[2]]*grupy[,k])
            nn=nn+1
         }
         data.frame(st1,st2,st3,ile)
      }, grupy=grupy)
   }

   do.call("rbind", trojki)
}
