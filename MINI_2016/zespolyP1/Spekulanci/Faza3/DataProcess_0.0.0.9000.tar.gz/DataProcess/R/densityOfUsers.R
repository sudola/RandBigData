##' Funkja zagęszczenia ekspozycji
##'
##' Funkcja wskazuje na zagęszczenie przy danym eksponacie w zależności od godziny
##'
##' @param dane - Ramka danych z logami użytkowników
##'
##' @export
##' @import dplyr
##' @import stringi
##'



densityOfUsers<-function(dane){
   require(dplyr)
   require(stringi)

   dane$time=as.numeric(substr(dane$time,1,2))
   godz=t(dane%>%select(time)%>%distinct())
   code=t(dane%>%select(hostname)%>%distinct())
   dane=dane%>%mutate(weekday=weekdays(as.Date(paste(year,month,day,sep="-"))))
   wday=t(dane%>%select(weekday)%>%distinct())
   n=length(wday)*length(godz)+1
   kod=toString(code)
   kod=stri_replace_all_fixed(kod, ",", "=numeric(n),")
   kod=paste("gestosc=data.frame(weekday=character(n), hour=numeric(n), ",kod, "=numeric(n))",sep = "")
   eval(parse(text=kod))
   levels(gestosc$weekday)=wday
   i=1
   for(g in godz){
      for(wd in wday){
         gestosc[i,1]=wd
         kod=toString(as.vector(t(dane%>%select(weekday, time, hostname)%>%filter(time==g, weekday==wd)%>%group_by(hostname)%>%summarise(ile=n())%>%select(ile, hostname))))
         kod=stri_replace_all_fixed(kod, ", c", "->c")
         kod=stri_replace_all_fixed(kod, ", ", ";")
         eval(parse(text=kod))
         kod=toString(code)
         kod=paste("gestosc[i,-1]=c(g, ",kod,")",sep = "")
         eval(parse(text=kod))
         i=i+1
      }
   }
   for(i in 1:length(code)){
      gestosc[n,i+2]=sum(na.omit(gestosc[,i+2]))
   }
   gestosc
}
