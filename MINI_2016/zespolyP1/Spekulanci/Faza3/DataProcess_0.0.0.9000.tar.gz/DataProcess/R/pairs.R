##'
##' Funckja zwracająca liczności wszystkich par
##'
##' Funkcja zwraca pary eksponatów, które pojawiają się w ścieżkach
##'
##' @param grupy - Ramka danych z pogrupowanymi wystąpieniami eksponatów w ścieżkach. Składa się z samych zmiennych numeryccznych przyjmujących wartości 0 i 1.
##'
##' @export
##'

pairs<-function(grupy){
   stopifnot(all(sapply(grupy, unique) %in% c(0,1)), ncol(grupy)>1)

   n=ncol(grupy)
   code=colnames(grupy)
   l=lista(n)

   pary=lapply(l, function(i, grupy){
      st1=code[i[1]]
      st2=code[i[2]]
      ile=sum(grupy[,i[1]]*grupy[,i[2]])
      data.frame(st1,st2,ile)
   }, grupy=grupy)

   do.call("rbind", pary)
}
