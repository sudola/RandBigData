##' Funkcja tworząca macierz przejść
##'
##' Fuunkcja wylicza z danych macierz przejścia w k-krokach
##'
##' @param logi - dane z logowań do stanowisk
##' @param k - rządana liczba kroków przejścia
##'
##' @export
##' @import stringi
##'
TransitionMatrix<- function(logi, k){
  require(dplyr)

  n=length(unique(logi$hostname))

  posort=logi%>%filter(duration>=5)%>%group_by(year,month,day,user)%>%arrange(time)

  dlug=nrow(posort[,1])

  ramka1=posort[-(dlug:(dlug-k+1)),]
  ramka2=posort[-(1:k),]
  names(ramka2)=c("year2","month2",  "day2" , "time2", "duration2","user2", "hostname2")
  razem=cbind(ramka1,ramka2)
  wynik=razem%>%filter(user==user2)%>%select(hostname,hostname2)%>%group_by(hostname,hostname2)%>%summarise(ile=n())

  m2=matrix(0,nrow=n,ncol=n)
  m2=as.data.frame(m2)
  names(m2)=unique(logi$hostname)
  rownames(m2)=unique(logi$hostname)

  dl=length(wynik$hostname)

  for (i in 1:dl)
  {
    m2[wynik$hostname[i],wynik$hostname2[i]]=wynik$ile[i]
  }
  for(i in 1:n)
  {
    m2[i,]=m2[i,]/sum(m2[i,])
  }

  m2
}
