#' Opis danych
#'
#' Dane zawierają ilościowe zagęszczenie użytkowników z podziałem na godziny i dni tygodnia. Ostatni wiersz jest jest ilościowym zgęszczeniem sumarycznym.
#' Opis kolumn:
#' \itemize{
#'    \item weekday. Dzień tygodnia
#'    \item hour. Godzina
#'    \item pozostałe. Nazwy stanowisk
#' }
#'
#' @docType data
#' @keywords datasets
#' @name density
#' @usage data(density)
#'
NULL
