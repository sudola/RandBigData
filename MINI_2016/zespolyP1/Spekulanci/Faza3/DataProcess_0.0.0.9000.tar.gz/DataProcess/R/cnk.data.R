#' Opis danych
#'
#' Dane zawierają logowania z 14-05-2013 między godziną 12:00 a 13:00. Przykłądowe dane zwracane przez funkcję ReadLogs()
#' Opis kolumn:
#' \itemize{
#'    \item year. Rok
#'    \item month. Miesiac
#'    \item day. Dzień
#'    \item time. Godzina rozpoczęcia użytkowania eksponatu
#'    \item duration Czas użytkowania eksponatu
#'    \item user. Numer karty użytkownika
#'    \item hostname. Nazwa stanowiska
#' }
#'
#' @docType data
#' @keywords datasets
#' @name cnk.data
#' @usage data(cnk.data)
#'
NULL
