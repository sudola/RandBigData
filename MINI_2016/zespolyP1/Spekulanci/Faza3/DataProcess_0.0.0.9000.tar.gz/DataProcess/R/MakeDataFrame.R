##' Funckcja wewnętrzna
##'
##' Tworzy ramkę danych z wczytanego pliku .log
##'
##' @param lines - wyczyszczona zawartość pliku .log
##' @param year - rok obrabianego pliku
##' @param month - miesiąc obrabianego pliku
##' @param h - hostname obrabianego pliku
##'

MakeDataFrame<-function(lines, rok, mies, h){
   data1 <- vector("list",27)
   i=1
   repeat{
      if (length(lines)==0) break
      day <- substr(lines[1], 1, 7)
      lselect <- stri_detect_regex(lines, day)
      day <- as.numeric(substr(day,5,6))
      lday <- lines[lselect]
      lines <- lines[!lselect]
      if(is.na(day)) next
      wd=weekdays(strptime(paste(rok, mies, day), "%Y %m %d"))
      if( wd == weekdays(strptime(paste(1991, 11, 04), "%Y %m %d")) ) next
      finish_user = start_user = stri_detect_regex(lday, "Added visitor ")
      if (sum(start_user) == 0) next
      finish_user[finish_user][1] <- FALSE
      finish_user=c(finish_user[-1], TRUE)
      start_user <- lday[start_user]
      user <- as.numeric(stri_extract_first_regex(start_user, "(?<=Added visitor )[0-9]+"))
      time <- strptime(substr(start_user, 8, 15), "%H:%M:%S")
      finish <- strptime(substr(lday[finish_user], 8, 15), "%H:%M:%S")
      duration <- finish-time
      time <- substr(time,12,19)
      year <- rep(rok, length(user))
      month <- rep(mies, length(user))
      day <- rep(day, length(user))
      hostname <- rep(h, length(user))
      data1[[i]] <- data.frame(year, month, day, time, duration, user, hostname)
      i=i+1
   }
   if(i==1) return(NULL)
   do.call("rbind", data1)
}
