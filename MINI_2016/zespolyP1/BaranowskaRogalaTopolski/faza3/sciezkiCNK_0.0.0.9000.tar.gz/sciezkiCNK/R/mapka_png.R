#' @title Mapa CNK
#' 
#' @description 
#' Plik PNG zawierający mapę wystawy ReGeneracja.
#' 
#' @docType data
#' @keywords datasets
#' @name mapka_png
#' @usage data(mapka_png)
#'
#'
#'
#'
NULL