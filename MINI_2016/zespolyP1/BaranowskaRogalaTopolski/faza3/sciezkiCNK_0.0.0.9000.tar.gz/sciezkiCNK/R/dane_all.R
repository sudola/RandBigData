#' @title Główny zbiór danych
#'
#' @description
#' Zbiór scieżek dla każdego dnia i dla poszczególnych godzin
#' 
#' @docType data
#' @keywords datasets
#' @name dane_all
#' @usage data(dane_all)
#'
#'
#'
#'
NULL