#' @title Słownik urządzeń
#' 
#' @description 
#' Zbiór nazw, kodów i współrzędnych na mapie dla odpowiednich stacji
#' @docType data
#' @keywords datasets
#' @name slownik_urz
#' @usage data(slownik_urz)
#'
#'
#'
#'
NULL