#' Współrzędne x eksponatów cnk.
#' 
#' Wektor zawierający współrzędne x eksponatów na mapce cnk
#' (kolejnosc współrzędnych odpowiada kolejności nazw wektora "eksponaty").
#'
#' @docType data
#' @name wspX
#' @format Wektor numeryczny o długości 59.
#' 

NULL