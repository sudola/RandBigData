#' Mapa cnk.
#' 
#' Obrazek w postaci obiektu array wczytany funkcją readPNG z pakietu png.
#'
#' @docType data
#' @name img
#' @format Obiekt array.
#' 

NULL