#' Pełne nazwy eksponatów cnk.
#' 
#' Faktor pełnych nazw eksponatów cnk.
#' 
#' @docType data
#' @name pelne_nazwy
#' @format Faktor zawierający 94 elementy.
#' 

NULL