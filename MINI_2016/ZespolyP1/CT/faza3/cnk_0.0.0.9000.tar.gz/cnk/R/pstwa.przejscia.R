#' Funkcja obliczająca macierz prawdopodobieńst przejscia
#' 
#' Funkjca oblicza macierz prawdopodobieństw przejścia w jednym kroku z jednego
#' eksponatu do drugiego dla każdej pary eksponatów. Dane są wczytywane z bazy
#' SQLite znajdującej się w pliku baza i zapisywane są do pliku .rda o nazwie
#' wyjscie.
#' 
#' @param baza Ścieżka do wejściowej bazy SQLitowej.
#' @param wyjscie Sciezka do pliku wyjściowego.
#' @return NULL
#' @import RSQLite
#' @import dplyr
#' @import magrittr
#' @export
#'
#'


pstwa.przejscia <- function(baza, wyjscie = "pstwa.rda") {
    
    db <- dbConnect(SQLite(), baza)
    dane <- dbReadTable(db, "interakcje")
    dbDisconnect(db)
    
    dane$poczatek <- strptime(dane$poczatek, '%Y-%m-%d %H:%M:%S')
    
    
    # sortowanie w grupach
    dane %>% group_by(dzien = as.Date(poczatek), gosc) %>%
        arrange(poczatek) -> dane
    
    
    eks <- unique(dane$eksponat)
    
    n <- nrow(dane)
    
    # ostatni eksponat w scieżce
    dane$ostatni <- c(dane$gosc[-n] != dane$gosc[-1], 1)
    
    
    # zlicza dla kazdej pary eksponatow (e1, e2) ile razy e2 był w sciezce po e1
    tabela <- table(dane$eksponat[-n], dane$eksponat[-1],
                    dane$ostatni[-n])[,,1]
    
    licznosci <- table(dane$eksponat, dane$ostatni)[,1]
    
    
    pstwa <- tabela / licznosci
    
    save(pstwa, file = wyjscie)
    
    invisible()
}