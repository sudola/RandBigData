#' Nazwy eksponatów cnk.
#' 
#' Wektor nazw eksponatów cnk
#' 
#' @docType data
#' @name eksponaty
#' @format Wektor napisów zawierający 59 elementów.
#' 

NULL