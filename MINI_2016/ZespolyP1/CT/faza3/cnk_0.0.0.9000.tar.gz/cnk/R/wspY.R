#' Współrzędne y eksponatów cnk.
#' 
#' Wektor zawierający współrzędne y eksponatów na mapce cnk
#' (kolejnosc współrzędnych odpowiada kolejności nazw wektora "eksponaty").
#'
#' @docType data
#' @name wspY
#' @format Wektor numeryczny o długości 59.
#' 

NULL