# Projekt 'Centrum Nauki Kopernik' -  R And Big Data 2015/2016
### Zofia Rogala, Ewa Baranowska, Bartosz Topolski

### Faza 3 projektu:

Ostateczna wersja aplikacji znajduje si� na stronie https://baranowskae.shinyapps.io/dodanie_apki_proba_1/, 
a pakiet u�yty w aplikacji dost�pny jest pod adresem https://github.com/topolskib/sciezkiCNK. 
Pakiet mo�na zainstalowa� przy pomocy polecenia `devtools::install_github(repo = "topolskib/sciezkiCNK")`. 
