library(testthat)
library(OpinieOBankach)

test_check("OpinieOBankach")
