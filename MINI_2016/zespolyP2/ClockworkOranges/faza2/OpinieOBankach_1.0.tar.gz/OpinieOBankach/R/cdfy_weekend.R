#' Dystrybuanty empiryczne dla weekendu.
#'
#' Obiekt zawiera dystrybuanty empiryczne rozkładu występowania słów kluczowych dla awarii podczas weekendu (sobota - niedziela).
#' Słowa kluczowe to "problem", "działać", "utrudnienie", "reklamacja", "awaria", "błąd". 
#'
#' @docType data
#' @name cdfy_weekend
#' @usage cdfy_weekend
#' @format list
NULL
