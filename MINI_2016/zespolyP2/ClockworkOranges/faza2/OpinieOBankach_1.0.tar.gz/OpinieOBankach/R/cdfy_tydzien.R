#' Dystrybuanty empiryczne dla dni roboczych.
#'
#' Obiekt zawiera dystrybuanty empiryczne rozkładu występowania słów kluczowych dla awarii podczas dni roboczych (poniedziałek - piątek).
#' Słowa kluczowe to "problem", "działać", "utrudnienie", "reklamacja", "awaria", "błąd". 
#'
#' @docType data
#' @name cdfy_tydzien
#' @usage cdfy_tydzien
#' @format list
NULL
