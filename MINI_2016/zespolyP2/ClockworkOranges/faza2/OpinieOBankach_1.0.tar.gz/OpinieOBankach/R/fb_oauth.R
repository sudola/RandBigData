#' Token do pobierania danych z facebooka
#'
#' Token pozwalający na pobieranie postów z facebooka.
#'
#' @docType data
#' @name fb_ouath
#' @usage fb_oauth
#' @format environment
NULL
